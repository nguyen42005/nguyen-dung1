
DB_DRIVER = 'ODBC Driver 17 for SQL Server'
DB_SERVER = 'ADMIN'           
DB_NAME = 'secure_app'        
USE_WINDOWS_AUTH = True       #Windows Authentication
DB_USERNAME = 'Admin'
DB_PASSWORD = 'Admin'
